#!/bin/sh
mv /usr/local/apache2/downloads/index.html /usr/local/apache2/htdocs/
mv /usr/local/apache2/downloads/fakeimage.png /usr/local/apache2/htdocs
mv /usr/local/apache2/downloads/virus_character.png /usr/local/apache2/htdocs
mv /usr/local/apache2/downloads/style.css /usr/local/apache2/htdocs
mv /usr/local/apache2/downloads/version.txt /usr/local/apache2/cgi-bin/