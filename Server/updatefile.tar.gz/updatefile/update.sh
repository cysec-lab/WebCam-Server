#!/bin/sh
mv /usr/local/apache2/downloads/version.txt /usr/local/apache2/cgi-bin/